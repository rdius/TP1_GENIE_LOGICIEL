/**
 * 
 */
/**
 * @author rdius
 *
 */
package com.all.manipulation;